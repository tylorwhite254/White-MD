'use strict'

const { askWithProviders, askProvider } = require('../lib/ai-providers')

const COMMANDS = [
  'chatgpt1', 'chatgpt2', 'chatgpt3', 'chatgpt4', 'chatgptplus', 'gpt35', 'gpt4', 'gpt4o', 'gpt4omini',
  'gemini1', 'gemini2', 'gemini3', 'geminipro', 'geminiflash', 'geminiultra',
  'codegpt', 'cursorai', 'blackbox', 'phind', 'windsurf',
  'devin', 'codegemini', 'codeqwen', 'starcoder2', 'codellama',
  'llama2', 'llama3', 'mixtral', 'qwen', 'phi4', 'bard', 'kimi', 'kimihelp', 'moonshot', 'kiamiga',
  'lumin', 'lumina', 'luminai', 'lightai', 'perplexity', 'perplex', 'askai', 'brain', 'think',
  'mathgpt', 'math', 'algebra', 'geometry', 'grammar', 'spellcheck', 'correct',
  'grammarly'
].map(command => command.replace(/\s+/g, ''))

module.exports = {
  command: COMMANDS,
  description: 'AI compatibility aliases using the configured White MD provider fallback chain',

  async execute({ socket, jid, args, message, command, logger }) {
    const prompt = args.join(' ').trim()
    if (!prompt) {
      await socket.sendMessage(jid, { text: `Usage: .${command} your question` }, { quoted: message })
      return
    }
    try {
      const directGemini = ['gemini1', 'gemini2', 'gemini3', 'geminipro', 'geminiflash', 'geminiultra'].includes(command)
      const result = directGemini
        ? { answer: await askProvider('gemini', prompt), provider: 'gemini' }
        : await askWithProviders(prompt)
      const { answer, provider } = result
      await socket.sendMessage(jid, { text: answer, contextInfo: { externalAdReply: { title: `White MD ${command}`, body: `Provider: ${provider}`, mediaType: 1 } } }, { quoted: message })
    } catch (error) {
      logger.error({ err: error, command }, 'AI alias failed')
      await socket.sendMessage(jid, { text: 'All configured AI providers are unavailable. Check AI_PROVIDERS and try again later.' }, { quoted: message })
    }
  }
}
